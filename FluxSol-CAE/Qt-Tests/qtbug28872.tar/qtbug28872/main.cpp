#include <QMainWindow>
#include <QApplication>
#include <QDockWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QDebug>
#include <QMouseEvent>

class MyEventFilter : public QObject {
public:
    MyEventFilter(QObject *parent ) : QObject(parent) {}

    bool eventFilter(QObject *, QEvent *e) {
        if (e->type() == QEvent::MouseButtonPress)
            qDebug() << ">>>>>>MOUSE PRESS <<<<";
        return false;
    }
};

int main(int argc, char *argv[])
{
    QApplication a(argc,argv);
    a.installEventFilter(new MyEventFilter(&a));
    QMainWindow mw;

    mw.setObjectName("MainWindow");
    QWidget *central = new QLabel("Label");
    central->setObjectName("Central");
    mw.setCentralWidget(central);
    QStringList args = QCoreApplication::arguments();
    args.pop_front();
    if (args.removeAll("-n")) {
        central->winId();
        qDebug("Native central widget");
    }
    if (!args.isEmpty())
        qDebug() << "INVALID ARGS" << args;
    QDockWidget *dw = new QDockWidget;
    dw->setObjectName("DockWidget");
    QWidget *dc = new QLabel("Dock");
    dc->setObjectName("Dock contents label");
    dw->setWidget(dc);
    mw.addDockWidget(Qt::LeftDockWidgetArea, dw);
    mw.show();
    return a.exec();
}


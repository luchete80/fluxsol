#include <QtWidgets>
#include <QGLWidget>

class QtOglDockWidgetTest : public QMainWindow {
public:
    QtOglDockWidgetTest();

protected:
    bool event(QEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);

private:
    void addToolBars();
    void removeToolBars();

private:
    std::vector<QToolBar *> mToolbars;
};

typedef QGLWidget CentralWidgetType;

inline QtOglDockWidgetTest::QtOglDockWidgetTest() {
    addToolBars();

    QDockWidget *dockWidget = new QDockWidget();
    dockWidget->setWidget(new CentralWidgetType());
    setCentralWidget(dockWidget);
}

inline bool QtOglDockWidgetTest::event(QEvent *event) {
    auto type = event->type();
    if (event->type() == QEvent::Paint) {
        setUpdatesEnabled(true);
        int i = 3;
    }
    return QMainWindow::event(event);
}

inline void QtOglDockWidgetTest::mouseReleaseEvent(QMouseEvent *event) {
    removeToolBars();
    addToolBars();
}

inline void QtOglDockWidgetTest::addToolBars() {
    for (int i = 0; i < 10; ++i) {
        QToolBar *tb = new QToolBar(QString::fromLatin1(""));
        addToolBar(Qt::ToolBarArea::TopToolBarArea, tb);
        mToolbars.push_back(tb);
        tb->repaint();
    }
}

inline void QtOglDockWidgetTest::removeToolBars() {
    for (int i = 0; i < mToolbars.size(); ++i)
        removeToolBar(mToolbars[i]);
    mToolbars.clear();
}

int main(int argc, char **argv) {

    QApplication app(argc, argv);

    QtOglDockWidgetTest test;
    test.show();

    return app.exec();
}
